---------------------------------------
	**  SWIFT MINING  **
		++++++
	HIGHEST PAYING MINER
		-----
		 BY
             AHMAD TAHA
---------------------------------------
***************************************
---------------------------------------
* FEATURES *
---------------------------------------
	- Highest Paying, Best Rates as compared to all Miners out there!
	- 5% REFER System to boost your income!
	- FLAT Design Website Interface! Smooth and not laggy website!
	- High DAILY REWARDS to TOP 3 MINERS!
	- Direct Payments to FaucetHub Microwallet!
	- Instant Payments, request whenever you want at 'btcautominer.cf'
	- NO MINIMUM Threshold!


---------------------------------------
* HOW TO START MINING *
---------------------------------------

To start mining first you need your pools.txt file which can be downloaded from our official site, btcautominer.cf . The file is fully preconfigured, you just need to download it and paste it into *this* folder, or in other words where your mining.exe file is.

After that, you can choose which what hardware you need to mine
	- if you want to use only CPU, then click CPU.bat file
	- if you want to use GPU only, then open GPU.bat file
	- if you want to uitlise both CPU and GPU, open file GPU_and_CPU.bat


---------------------------------------
* CONTACT US *
---------------------------------------

- Email : ahmadtahaco@gmail.com
- Telegram : @ahmadtaha_at
- FaucetHub : ahmadtaha
- BitcoinTalk : https://bitcointalk.org/index.php?topic=3465370.0

---------------------------------------
* THANK YOU FOR MINING HERE * * PLEASE POST YOUR FEEDBACKS HERE : https://bitcointalk.org/index.php?topic=3465370.0 *
---------------------------------------






